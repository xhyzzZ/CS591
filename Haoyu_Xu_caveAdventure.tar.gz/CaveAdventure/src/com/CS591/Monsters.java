package com.CS591;

public class Monsters {

    private String goblin;
    private String wombat;
    private String hobgoblinLord;

    public Monsters() {
        this.goblin = "goblin";
        this.wombat = "wombat";
        this.hobgoblinLord = "hobgoblinLord";
    }

    public String getGoblin() {
        return goblin;
    }

    public String getWombat() {
        return wombat;
    }

    public String getHobgoblinLord() {
        return hobgoblinLord;
    }

}
